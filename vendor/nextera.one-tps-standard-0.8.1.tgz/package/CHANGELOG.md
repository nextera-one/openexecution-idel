# Changelog

All notable changes to `@nextera.one/tps-standard` are documented here.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

---

## [0.8.1] — 2026-06-09

### Fixed

- **Native ESM is now loadable on Node.** The ESM build (`dist/esm`) previously
  emitted extensionless relative imports (e.g. `./drivers/gregorian`), which
  Node's ESM resolver rejects with `ERR_MODULE_NOT_FOUND`. All relative imports
  now carry explicit `.js` extensions, and `dist/esm/package.json` declares
  `{"type":"module"}` so Node treats the build as ESM without a reparse warning.
- **Crypto/zlib now work under ESM.** Node detection used `typeof require`, which
  is `undefined` in ESM even on Node — so `randomBytes`, `deflate`/`inflate`, and
  Ed25519 sign/verify all threw "not available in this environment" when the
  package was imported as ESM. Detection now uses `process.versions.node`,
  `randomBytes` prefers Web Crypto (available in both module systems), and Node
  builtins load via `process.getBuiltinModule` when `require` is absent.

### Changed

- ESM `tsconfig` uses `module: ESNext` so extensions are preserved in the emit.
- `experimentalResolver` enabled for `ts-node` so the test suite resolves the
  `.js`-suffixed source imports back to their `.ts` sources.

## [0.8.0] — 2026-04-04

### Added

- Indexed TPS time helpers: `TPS.toDayIndex()`, `TPS.fromDayIndex()`, `TPS.getDayFraction()`, `TPS.getSubDayMilliseconds()`, `TPS.toIndexedTime()`, `TPS.toIndexedURI()`, `TPS.expandIndexedTime()`, `TPS.compactIndexedTime()`.
- Indexed TPS syntax support for `T:tps.iN` and `T:tps.iN.F`.
- Explicit TPS week token support (`w`) in TPS native hierarchical strings.
- Boundary and round-trip tests for indexed TPS time and UID normalization.

### Changed

- Reworked the TPS native driver from a shifted-Gregorian projection to an epoch-based `12 × 4 × 7` calendar model.
- TPS native day boundaries now anchor at `07:00` Gregorian / UTC.
- TPS native conversion now derives `dayIndex`, `dayFraction`, `week`, and hierarchical coordinates from the same core day-index math.
- Indexed TPS inputs are expanded to hierarchical TPS before `TPSUID7RB` storage or signing.

### Fixed

- Indexed TPS validation now rejects malformed or non-canonical compact fractions and rejects indexed syntax on non-TPS calendars.

## [0.5.35] — 2026-03-04

### Added

- **`TPS.now(calendar?, opts?)`** — shorthand for `TPS.fromDate(new Date(), calendar, opts)`.
- **`TPS.diff(t1, t2)`** — returns elapsed time in milliseconds between two TPS strings (`t2 − t1`).
- **`TPS.add(tpsStr, duration)`** — returns a new TPS string shifted by a `{days, hours, minutes, seconds, milliseconds}` duration object. Preserves original calendar and time order.
- **Chinese Lunisolar calendar driver** (`chin`) — Huangdi year numbering (≈4722 = 2024 CE), Sexagenary ganzhi cycle, month formatting in romanized and Chinese character form (`zh` format).
- **`DriverManager` class** — dedicated driver registry. `TPS.driverManager` exposes `register()`, `get()`, `has()`, `list()`, and `unregister()`. The static `TPS.registerDriver()` / `TPS.getDriver()` methods are preserved as convenience shorthands.
- **`src/utils/timezone.ts`** — zero-dependency timezone utility using `Intl.DateTimeFormat`. Supports IANA names (`Asia/Tehran`), fixed offsets (`+03:30`), and common abbreviations (`IRST`, `JST`, `EST`, …).
- **Timezone-aware `TPS.toDate()`** — when a parsed TPS URI has a `;tz=` extension, the returned `Date` is automatically converted from local → UTC.
- **ESM dual-mode build** — `dist/esm/index.js` emitted via `tsconfig.esm.json`. `package.json` `"exports"` field routes `import` to ESM and `require` to CJS.
- **Browser IIFE bundle** — `dist/tps.min.js` (global `window.TPS`) built via Rollup (`npm run bundle`).

### Changed

- Internal driver registry moved from a private `Map` in `TPS` to `DriverManager`.
- `package.json`: added `"module"`, `"browser"`, `"exports"` fields; build script now also emits ESM.

---

## [0.5.34] — 2026-03-04

### Changed

- Version bump after authentication issue during 0.5.4 publish attempt.

---

## [0.5.33] — 2026-03-03

### Added

- Full library modularization:
  - `src/types.ts` — shared interfaces and enums.
  - `src/uid.ts` — `TPSUID7RB` binary UID logic.
  - `src/date.ts` — `TpsDate` wrapper with component caching.
  - `src/utils/env.ts` — Node.js / Browser polyfill layer.
  - `src/utils/calendar.ts` — centralized JDN math.
  - `src/utils/tps-string.ts` — TPS string build / parse utilities (breaks circular deps).
- Calendar drivers: **Persian** (`per`), **Hijri** (`hij`), **Julian** (`jul`), **Holocene** (`holo`).
- `TPS.parseCalendarDate()`, `TPS.fromCalendarDate()`, `TPS.formatCalendarDate()` convenience helpers.
- `TPS.sanitizeTimeInput()` — normalizes casing, whitespace, legacy `/T:` separator, and detects ascending order.

### Fixed

- Persian calendar JDN → month calculation typo (divisor 108 → 31).
- All circular dependencies between drivers and the main TPS class.

---

## [0.5.3] — 2026-03-02

### Changed

- Minor internal refactoring and stability fixes.

---

## [0.5.2] — 2026-02-28

### Added

- `TPSUID7RB` binary reversible IDs.
- Ascending (`TimeOrder.ASC`) time string support.
- Pre-`@` generic space anchors (`adm:`, `node:`, `net:ip4:`, `planet:`, …).
- Structural anchors (`bldg=`, `floor=`, `room=`, `zone=`).
- Geospatial cell anchors (`s2=`, `h3=`, `plus=`, `w3w=`).
- Actor anchor (`A:`), cryptographic signature (`!`).

---

## [0.5.0] — 2026-02-01

### Added

- Initial public release.
- Core TPS URI parsing, validation, and serialization.
- Gregorian (`greg`) and Unix (`unix`) built-in calendar drivers.
- `TpsDate` — Date-like wrapper with TPS conversion helpers.
